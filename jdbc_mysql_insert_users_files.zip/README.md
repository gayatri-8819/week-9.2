# Insert Users into MySQL using JDBC PreparedStatement

## Files
- `Main.java` — creates the `users` table if needed and inserts John Doe and Jane Doe using `PreparedStatement`.
- `schema.sql` — creates/selects the `mydatabase` database.

## Setup
1. Make sure MySQL Server is running.
2. Run `schema.sql` in MySQL Workbench or another MySQL client.
3. Edit `Main.java` and replace `your_password` with your MySQL password. Change `USERNAME` if you do not use `root`.
4. Add the MySQL Connector/J JAR to your Java project's classpath.

## Compile and run (Windows Command Prompt)
```bat
javac -cp ".;mysql-connector-j-<version>.jar" Main.java
java -cp ".;mysql-connector-j-<version>.jar" Main
```
Replace `<version>` with the version in the JAR filename. On macOS/Linux, use `:` instead of `;` in the classpath.

Expected output:
```text
Data inserted successfully.
```

Running the program more than once inserts another copy of each record because the table does not enforce unique names or emails.
